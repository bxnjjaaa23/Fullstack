package com.example.demo.repository;

import com.example.demo.model.MetodoPago;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class MetodoPagoRepository {

    private static final List<MetodoPago> metodosPago = new ArrayList<>();

    public List<MetodoPago> obtenerTodos() {
        return metodosPago;
    }

    public void guardar(MetodoPago metodoPago) {
        metodosPago.removeIf(m -> m.getId().equals(metodoPago.getId()));
        metodosPago.add(metodoPago);
    }

    public Optional<MetodoPago> buscarPorId(Long id) {
        return metodosPago.stream().filter(m -> m.getId().equals(id)).findFirst();
    }

    public void eliminarPorId(Long id) {
        metodosPago.removeIf(m -> m.getId().equals(id));
    }

    public List<MetodoPago> buscarPorClienteId(Long clienteId) {
        return metodosPago.stream()
                .filter(m -> m.getClienteId().equals(clienteId))
                .collect(Collectors.toList());
    }
}
