package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Gerente;
import com.example.demo.repository.GerenteRepository;

@Service
public class GerenteService {

    @Autowired
    private GerenteRepository gerenteRepository;

    public Gerente iniciarSesion(String id, String contrasena) {
        return gerenteRepository.iniciarSesion(id, contrasena);
    }
}

