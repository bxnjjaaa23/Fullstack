package com.example.demo.services;

import com.example.demo.model.Pedido;
import com.example.demo.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RepartidorService {

    @Autowired
    private PedidoRepository pedidoRepository; // Usamos el repositorio correcto

    public boolean marcarPedidoComoEntregado(Long pedidoId, Long repartidorId) {
        Optional<Pedido> pedidoOpt = pedidoRepository.buscarPorId(pedidoId);
        if (pedidoOpt.isPresent()) {
            Pedido pedido = pedidoOpt.get();
            if (pedido.getRepartidorId().equals(repartidorId)) {
                pedido.setEstado("ENTREGADO");
                pedidoRepository.guardar(pedido); // Método correcto
                return true;
            }
        }
        return false;
    }
}
