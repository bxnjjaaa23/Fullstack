package com.example.demo.repository;

import com.example.demo.model.ItemPedido;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ItemPedidoRepository {

    private final Map<Long, ItemPedido> items = new HashMap<>();
    private long currentId = 1;

    public List<ItemPedido> findAll() {
        return new ArrayList<>(items.values());
    }

    public Optional<ItemPedido> findById(Long id) {
        return Optional.ofNullable(items.get(id));
    }

    public ItemPedido save(ItemPedido itemPedido) {
        if (itemPedido.getId() == null) {
            itemPedido.setId(currentId++);
        }
        items.put(itemPedido.getId(), itemPedido);
        return itemPedido;
    }

    public void deleteById(Long id) {
        items.remove(id);
    }
}
