package com.example.demo.controller;

import com.example.demo.model.ItemPedido;
import com.example.demo.services.ItemPedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/itempedidos")
public class ItemPedidoController {

    @Autowired
    private ItemPedidoService itemPedidoService;

    @GetMapping
    public List<ItemPedido> getAllItemPedidos() {
        return itemPedidoService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<ItemPedido> getItemPedidoById(@PathVariable Long id) {
        return itemPedidoService.findById(id);
    }

    @PostMapping
    public ItemPedido createItemPedido(@RequestBody ItemPedido itemPedido) {
        return itemPedidoService.save(itemPedido);
    }

    @PutMapping("/{id}")
    public ItemPedido updateItemPedido(@PathVariable Long id, @RequestBody ItemPedido itemPedido) {
        itemPedido.setId(id);
        return itemPedidoService.save(itemPedido);
    }

    @DeleteMapping("/{id}")
    public void deleteItemPedido(@PathVariable Long id) {
        itemPedidoService.deleteById(id);
    }
}
