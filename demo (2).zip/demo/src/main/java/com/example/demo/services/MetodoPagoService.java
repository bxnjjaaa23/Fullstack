package com.example.demo.services;

import com.example.demo.model.MetodoPago;
import com.example.demo.repository.MetodoPagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MetodoPagoService {

    @Autowired
    private MetodoPagoRepository metodoPagoRepository;

    public List<MetodoPago> obtenerTodos() {
        return metodoPagoRepository.obtenerTodos();
    }

    public void guardar(MetodoPago metodoPago) {
        metodoPagoRepository.guardar(metodoPago);
    }

    public Optional<MetodoPago> obtenerPorId(Long id) {
        return metodoPagoRepository.buscarPorId(id);
    }

    public void eliminar(Long id) {
        metodoPagoRepository.eliminarPorId(id);
    }

    public List<MetodoPago> obtenerPorClienteId(Long clienteId) {
        return metodoPagoRepository.buscarPorClienteId(clienteId);
    }
}
