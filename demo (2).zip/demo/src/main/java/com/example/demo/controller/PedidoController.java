package com.example.demo.controller;

import com.example.demo.model.Pedido;
import com.example.demo.services.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @GetMapping
    public List<Pedido> obtenerTodos() {
        return pedidoService.obtenerTodos();
    }

    @PostMapping
    public ResponseEntity<String> crearPedido(@RequestBody Pedido pedido) {
        pedidoService.guardar(pedido);
        return ResponseEntity.ok("Pedido creado correctamente");
    }
}
