package com.example.demo.controller;

import com.example.demo.model.MetodoPago;
import com.example.demo.services.MetodoPagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/metodos-pago")
public class MetodoPagoController {

    @Autowired
    private MetodoPagoService metodoPagoService;

    @PostMapping
    public ResponseEntity<String> crearMetodoPago(@RequestBody MetodoPago metodoPago) {
        metodoPagoService.guardar(metodoPago);
        return ResponseEntity.ok("Método de pago guardado correctamente");
    }

    @GetMapping
    public List<MetodoPago> obtenerTodos() {
        return metodoPagoService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MetodoPago> obtenerPorId(@PathVariable Long id) {
        Optional<MetodoPago> metodo = metodoPagoService.obtenerPorId(id);
        return metodo.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/cliente/{clienteId}")
    public List<MetodoPago> obtenerPorCliente(@PathVariable Long clienteId) {
        return metodoPagoService.obtenerPorClienteId(clienteId);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> actualizarMetodoPago(@PathVariable Long id, @RequestBody MetodoPago nuevoMetodo) {
        Optional<MetodoPago> existente = metodoPagoService.obtenerPorId(id);
        if (existente.isPresent()) {
            MetodoPago metodo = existente.get();
            metodo.setTipo(nuevoMetodo.getTipo());
            metodo.setDetalle(nuevoMetodo.getDetalle());
            metodoPagoService.guardar(metodo);
            return ResponseEntity.ok("Método de pago actualizado");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarMetodoPago(@PathVariable Long id) {
        metodoPagoService.eliminar(id);
        return ResponseEntity.ok("Método de pago eliminado");
    }
}

