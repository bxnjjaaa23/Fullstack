package com.example.demo.controller;

import com.example.demo.model.Cliente;
import com.example.demo.services.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("clientes")
@CrossOrigin(origins = "*")
@Tag(name = "Clientes", description = "Listar Cliente")

public class ClienteController {

    private final ClienteService servicio;

    public ClienteController(ClienteService servicio) { this.servicio = servicio; }

    @GetMapping
    @Operation(summary = "Obtener todos los clientes", description =
    "Obtiene una lista de todos los clientes")
    @ApiResponse(responseCode = "200", description = "Un vio total")

    public List<Cliente> listar() {
        return servicio.obtenerTodos();
    }


    @GetMapping("/{id}")
    @Operation(summary = "Obtener clientes", description =
    "Obtiene los clientes")
    public Cliente obtener(@PathVariable Long id) {
        return servicio.obtenerPorId(id);
    }

    @PostMapping
    @Operation(summary = "Crear clientes", description =
    "Clientes creados")
    public void crear(@RequestBody Cliente cliente) {
        servicio.guardar(cliente);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar clientes", description =
    "Clientes")
    public void actualizar(@PathVariable Long id, @RequestBody Cliente datos) {
        datos.setId(id);
        servicio.guardar(datos);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar clientes", description =
    "Clientes a eliminar")
    public void eliminar(@PathVariable Long id) {
        servicio.eliminar(id);
    }
}
