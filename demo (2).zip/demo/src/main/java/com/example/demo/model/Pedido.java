package com.example.demo.model;

public class Pedido {
    private Long id;
    private Long repartidorId;
    private String estado;

    public Pedido() {}

    public Pedido(Long id, Long repartidorId, String estado) {
        this.id = id;
        this.repartidorId = repartidorId;
        this.estado = estado;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getRepartidorId() { return repartidorId; }
    public void setRepartidorId(Long repartidorId) { this.repartidorId = repartidorId; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}