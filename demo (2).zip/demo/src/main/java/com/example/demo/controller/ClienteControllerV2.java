package com.example.demo.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.assemblers.ClienteModelAssembler;
import com.example.demo.model.Cliente;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("Hateoas")
public class ClienteControllerV2 {

    @Autowired
    private ClienteController clienteController; 

    @Autowired
    private ClienteModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Cliente>> getAllCliente() {
        List<EntityModel<Cliente>> clientes = clienteController.listar()
                .stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(clientes,
                linkTo(methodOn(ClienteControllerV2.class).getAllCliente()).withSelfRel());
    }

    @GetMapping(value = "/{codigo}", produces = MediaTypes.HAL_JSON_VALUE)
    public EntityModel<Cliente> getClienteByCodigo(@PathVariable String codigo) {
        Cliente cliente = clienteController.obtener(Long.parseLong(codigo));
        return assembler.toModel(cliente);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Cliente>> createCliente(@RequestBody Cliente cliente) {
        clienteController.crear(cliente);
        return ResponseEntity
                .created(linkTo(methodOn(ClienteControllerV2.class)
                        .getClienteByCodigo(cliente.getId().toString())).toUri())
                .body(assembler.toModel(cliente));
    }

    @PutMapping(value = "/{codigo}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Cliente>> updateCliente(@PathVariable String codigo, @RequestBody Cliente cliente) {
        cliente.setId(Long.parseLong(codigo));
        clienteController.actualizar(cliente.getId(), cliente);
        return ResponseEntity.ok(assembler.toModel(cliente));
    }

    @DeleteMapping(value = "/{codigo}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<?> deleteCliente(@PathVariable String codigo) {
        clienteController.eliminar(Long.parseLong(codigo));
        return ResponseEntity.noContent().build();
    }
}
