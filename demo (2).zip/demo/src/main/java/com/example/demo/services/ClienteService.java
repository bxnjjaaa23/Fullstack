package com.example.demo.services;

import com.example.demo.model.Cliente;
import com.example.demo.repository.ClienteRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {

    private final ClienteRepository repo;

    public ClienteService(ClienteRepository repo) 
    { this.repo = repo; }

    public List<Cliente> obtenerTodos()       
    { return repo.findAll(); }

    public Cliente obtenerPorId(Long id)      
    { return repo.findById(id).orElse(null); }

    public void guardar(Cliente cliente)      
    { repo.save(cliente); }

    public void eliminar(Long id)             
    { repo.deleteById(id); }
}
