package com.example.demo.model;

public class MetodoPago {
    private Long id;
    private Long clienteId;
    private String tipo;
    private String detalle;

    public MetodoPago() {}

    public MetodoPago(Long id, Long clienteId, String tipo, String detalle) {
        this.id = id;
        this.clienteId = clienteId;
        this.tipo = tipo;
        this.detalle = detalle;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getDetalle() { return detalle; }
    public void setDetalle(String detalle) { this.detalle = detalle; }
}