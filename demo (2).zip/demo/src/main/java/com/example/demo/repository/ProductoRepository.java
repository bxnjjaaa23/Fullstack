package com.example.demo.repository;

import com.example.demo.model.Producto;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ProductoRepository {

    private final Map<Long, Producto> productos = new HashMap<>();
    private long currentId = 1;

    public List<Producto> findAll() {
        return new ArrayList<>(productos.values());
    }

    public Optional<Producto> findById(Long id) {
        return Optional.ofNullable(productos.get(id));
    }

    public Producto save(Producto producto) {
        if (producto.getId() == null) {
            producto.setId(currentId++);
        }
        productos.put(producto.getId(), producto);
        return producto;
    }

    public void deleteById(Long id) {
        productos.remove(id);
    }
}
