package com.example.demo.controller;

import com.example.demo.services.RepartidorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/repartidor")
public class RepartidorController {

    @Autowired
    private RepartidorService repartidorService;

    @PutMapping("/pedido/{pedidoId}/entregar/{repartidorId}")
    public ResponseEntity<String> marcarPedidoComoEntregado(@PathVariable Long pedidoId, @PathVariable Long repartidorId) {
        boolean entregado = repartidorService.marcarPedidoComoEntregado(pedidoId, repartidorId);
        if (entregado) {
            return ResponseEntity.ok("Pedido marcado como entregado");
        } else {
            return ResponseEntity.badRequest().body("No se pudo marcar el pedido como entregado");
        }
    }
}
