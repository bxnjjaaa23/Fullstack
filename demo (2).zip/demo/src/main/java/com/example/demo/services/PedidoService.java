package com.example.demo.services;

import com.example.demo.model.Pedido;
import com.example.demo.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    public List<Pedido> obtenerTodos() {
        return pedidoRepository.obtenerTodos();
    }

    public Optional<Pedido> obtenerPorId(Long id) {
        return pedidoRepository.buscarPorId(id);
    }

    public void guardar(Pedido pedido) {
        pedidoRepository.guardar(pedido);
    }
}
