package com.example.demo.repository;

import com.example.demo.model.Pedido;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class PedidoRepository {
    private static final List<Pedido> pedidos = new ArrayList<>();

    public List<Pedido> obtenerTodos() {
        return pedidos;
    }

    public Optional<Pedido> buscarPorId(Long id) {
        return pedidos.stream().filter(p -> p.getId().equals(id)).findFirst();
    }

    public void guardar(Pedido pedido) {
        pedidos.removeIf(p -> p.getId().equals(pedido.getId()));
        pedidos.add(pedido);
    }
}
