package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import com.example.demo.model.Gerente;

@Repository
public class GerenteRepository {

    public Gerente iniciarSesion(String id, String contrasena) {
        if (id.equals("admin") && contrasena.equals("1234")) {
            System.out.println("Iniciaste bien .");
            return new Gerente(id, contrasena);
        } else {
            System.out.println("ID o contraseña incorrectos.");
            return null;
        }
    }

    public void cerrarSesion() {
        System.out.println("Sesión cerrada exitosamente.");
    }
}
